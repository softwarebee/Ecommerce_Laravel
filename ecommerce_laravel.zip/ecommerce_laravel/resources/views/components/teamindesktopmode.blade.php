<h1 class="black-text" style="font-weight:bold;">OUR TEAM</h1>
    <div  style="border-bottom: 2px solid black;width:100px; "></div>
    <br>
                       
        <p style=" font-family: 'Balsamiq Sans', cursive;"> </p>

      <div class="row team px-5 wow animated fadeIn slow" style="margin-left:15%;"   >
          
          <div class="col-md-3" >
                <div class="card mb-2">
                    <img class="card-img-top  animated pulse infinite slow" src="https://www.btao.in/resources/images/ourteam/rahul.jpg"
                      alt="Card image cap">
                    <div align="left" class="card-body">
                      <h6 class="card-title font-weight-bold" style="font-family: 'Josefin Sans', sans-serif;">Rahul</h6>
                      <p class="card-text" style="font-family: 'Balsamiq Sans', cursive;margin-top:-12px;font-size:10px;"><i> Desgination</i></p>
                  
                    </div>
                </div>
                    
          </div>
       
          <div class="col-md-3" >
            <div class="card mb-2">
                <img class="card-img-top  animated pulse infinite slow" src="https://www.btao.in/resources/images/ourteam/rahul.jpg"
                  alt="Card image cap">
                <div align="left" class="card-body">
                  <h6 class="card-title font-weight-bold" style="font-family: 'Josefin Sans', sans-serif;">Rahul</h6>
                  <p class="card-text" style="font-family: 'Balsamiq Sans', cursive;margin-top:-12px;font-size:10px;"><i> Desgination</i></p>
              
                </div>
            </div>
                
      </div> <div class="col-md-3" >
        <div class="card mb-2">
            <img class="card-img-top  animated pulse infinite slow" src="https://www.btao.in/resources/images/ourteam/rahul.jpg"
              alt="Card image cap">
            <div align="left" class="card-body">
              <h6 class="card-title font-weight-bold" style="font-family: 'Josefin Sans', sans-serif;">Rahul</h6>
              <p class="card-text" style="font-family: 'Balsamiq Sans', cursive;margin-top:-12px;font-size:10px;"><i> Desgination</i></p>
          
            </div>
        </div>
            
  </div>
        
      
      
      </div>
       
      <div class="row team px-5 py-5 wow animated fadeIn slow" style="margin-left:15%;"   >
            <div class="col-md-3" >
              <div class="card mb-2">
                  <img class="card-img-top  animated pulse infinite slow" src="https://www.btao.in/resources/images/ourteam/rahul.jpg"
                    alt="Card image cap">
                  <div align="left" class="card-body">
                    <h6 class="card-title font-weight-bold" style="font-family: 'Josefin Sans', sans-serif;">Rahul</h6>
                    <p class="card-text" style="font-family: 'Balsamiq Sans', cursive;margin-top:-12px;font-size:10px;"><i> Desgination</i></p>
                
                  </div>
              </div>
                  
        </div>

          <div class="col-md-3" >
            <div class="card mb-2">
                <img class="card-img-top  animated pulse infinite slow" src="https://www.btao.in/resources/images/ourteam/rahul.jpg"
                  alt="Card image cap">
                <div align="left" class="card-body">
                  <h6 class="card-title font-weight-bold" style="font-family: 'Josefin Sans', sans-serif;">Rahul</h6>
                  <p class="card-text" style="font-family: 'Balsamiq Sans', cursive;margin-top:-12px;font-size:10px;"><i> Desgination</i></p>
              
                </div>
            </div>
                
      </div>
      <div class="col-md-3" >
        <div class="card mb-2">
            <img class="card-img-top  animated pulse infinite slow" src="https://www.btao.in/resources/images/ourteam/rahul.jpg"
              alt="Card image cap">
            <div align="left" class="card-body">
              <h6 class="card-title font-weight-bold" style="font-family: 'Josefin Sans', sans-serif;">Rahul</h6>
              <p class="card-text" style="font-family: 'Balsamiq Sans', cursive;margin-top:-12px;font-size:10px;"><i> Desgination</i></p>
          
            </div>
        </div>
            
      </div>

        
        
      
      
      </div>
      