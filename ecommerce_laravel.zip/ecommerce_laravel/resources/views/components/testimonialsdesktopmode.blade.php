
    <div class=" mask rgba-black-strong" style="width:100%;background:white;">   
        <div class="container">
            <div class="row d-flex align-items-center " >
                <section align="center" style="padding:20px;"  class="wow fadeInUp" >
                        <h1 class="black-text" style="font-weight:bold;">TESTIMONIALS</h1>
                        <div style="border-bottom: 2px solid black;width:100px;margin-left:45%;"></div><br>
                           <!--  <p class="black-text" style=" font-family: 'Balsamiq Sans', cursive;">Here’s what some of our customers say about our work.</p>-->
                        <!-- List of Clients-->
                        <div align="center" id="carousel-example-multi2" class="carousel slide carousel-multi-item v-2 wow animated fadeInUp fast" data-ride="carousel"><div class="carousel-inner" role="listbox">
     
                            <div class="carousel-item active">
                                 <div class="row">
                                        <div class="col-md-4">
                                            <div class="card mb-2">
                                                <div class="card-body">
                                                       
                                                            <p align="left" style="float:left;">
                                                                <img src="{{asset('assets/img/testimonials/rahul.jpg')}}" class="z-depth-1" style="width:100px;">
                                                            </p>
                                                            <p ><span style="font-weight:bold;">Vijayanagaram Rahul</span> <br>Freelauncer</p>
                                                            <br><br>
                                                            <p align="left" class="card-text" style="font-family: 'Balsamiq Sans', cursive;display:block;">
                                                                <i>Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata 
                                                                Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata
                                                                </i>
                                                            </p>
                                                            
                                                </div>
                                            </div>                                        
                                        </div>
                                        <div class="col-md-4">
                                            <div class="card mb-2">
                                                <div class="card-body">
                                                       
                                                            <p align="left" style="float:left;">
                                                                <img src="{{asset('assets/img/testimonials/rahul.jpg')}}" class="z-depth-1" style="width:100px;">
                                                            </p>
                                                            <p ><span style="font-weight:bold;">Vijayanagaram Rahul</span> <br>Freelauncer</p>
                                                            <br><br>
                                                            <p align="left" class="card-text" style="font-family: 'Balsamiq Sans', cursive;display:block;">
                                                                <i>Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata 
                                                                Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata
                                                                </i>
                                                            </p>
                                                            
                                                </div>
                                            </div>                                        
                                        </div>
                                        <div class="col-md-4">
                                            <div class="card mb-2">
                                                <div class="card-body">
                                                       
                                                            <p align="left" style="float:left;">
                                                                <img src="{{asset('assets/img/testimonials/rahul.jpg')}}" class="z-depth-1" style="width:100px;">
                                                            </p>
                                                            <p ><span style="font-weight:bold;">Vijayanagaram Rahul</span> <br>Freelauncer</p>
                                                            <br><br>
                                                            <p align="left" class="card-text" style="font-family: 'Balsamiq Sans', cursive;display:block;">
                                                                <i>Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata 
                                                                Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata
                                                                </i>
                                                            </p>
                                                            
                                                </div>
                                            </div>                                        
                                        </div> 
                                    
                                </div>
                            </div>
                            
                            <div class="carousel-item ">
                                 <div class="row">
                                        <div class="col-md-4">
                                            <div class="card mb-2">
                                                <div class="card-body">
                                                       
                                                            <p align="left" style="float:left;">
                                                                <img src="{{asset('assets/img/testimonials/sandeep.jpg')}}" class="z-depth-1" style="width:100px;">
                                                            </p>
                                                            <p ><span style="font-weight:bold;">sandeep</span> <br>Freelauncer</p>
                                                            <br><br>
                                                            <p align="left" class="card-text" style="font-family: 'Balsamiq Sans', cursive;display:block;">
                                                                <i>Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata 
                                                                Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata
                                                                </i>
                                                            </p>
                                                            
                                                </div>
                                            </div>                                        
                                        </div>
                                        <div class="col-md-4">
                                            <div class="card mb-2">
                                                <div class="card-body">
                                                       
                                                            <p align="left" style="float:left;">
                                                                <img src="{{asset('assets/img/testimonials/sandeep.jpg')}}" class="z-depth-1" style="width:100px;">
                                                            </p>
                                                            <p ><span style="font-weight:bold;">sandeep</span> <br>Freelauncer</p>
                                                            <br><br>
                                                            <p align="left" class="card-text" style="font-family: 'Balsamiq Sans', cursive;display:block;">
                                                                <i>Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata 
                                                                Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata
                                                                </i>
                                                            </p>
                                                            
                                                </div>
                                            </div>                                        
                                        </div>
                                        <div class="col-md-4">
                                            <div class="card mb-2">
                                                <div class="card-body">
                                                       
                                                            <p align="left" style="float:left;">
                                                                <img src="{{asset('assets/img/testimonials/sandeep.jpg')}}" class="z-depth-1" style="width:100px;">
                                                            </p>
                                                            <p ><span style="font-weight:bold;">sandeep</span> <br>Freelauncer</p>
                                                            <br><br>
                                                            <p align="left" class="card-text" style="font-family: 'Balsamiq Sans', cursive;display:block;">
                                                                <i>Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata 
                                                                Minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat tarad limino ata
                                                                </i>
                                                            </p>
                                                            
                                                </div>
                                            </div>                                        
                                        </div> 
                                    
                                </div>
                            </div>
                            
            
         
                        </div>
                        <!--Controls-->
                        <div class="controls-top">
                            <a class="  animated pulse infinite slow" style="border-radius:50px;"  href="#carousel-example-multi2" data-slide="prev"><i class="fas fa-chevron-left"></i></a>
                            <a class=" px-3 animated pulse infinite slow" style="border-radius:50px;"  href="#carousel-example-multi2" data-slide="next"><i class="fas fa-chevron-right"></i></a>
                        </div>
                        <!--/.Controls-->
                
                </section>
            </div>
       </div>
    </div>
 