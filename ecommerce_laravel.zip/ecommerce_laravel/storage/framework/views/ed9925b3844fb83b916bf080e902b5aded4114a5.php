<!-- Central Modal Medium Success -->
<div class="modal modal-large fade" id="show_Order_Status_Modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
aria-hidden="true">
    <div  align="center" class="modal-dialog modal-notify modal-success modal-xl" role="document" >
        <!--Content-->
        <div class="modal-content">
        <!--Header-->
        <div class="modal-header">
            <p class="heading lead">Order Status for Order Number : <?php echo e(session('Order_id')); ?> </p>

            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true" class="white-text">&times;</span>
            </button>
        </div>

        <!--Body-->
        <div class="modal-body">
           <!-- <h3>Order No : <?php echo e(session('Order_id')); ?> </h3>-->
            <!-- Order Status Table-->
                <?php if(session('Order_Cancel_Status')==1 && session('Delivery_Status')=='pending'): ?>
                      <p class=" animated rotateIn"> 
                        <i class="fas fa-ban fa-3x"></i>
                        </p>
                        <h3>Order Cancelled   </h3>
                <?php endif; ?>
                
                <?php if(session('Delivery_Status')!='pending'): ?>
                <p class=" animated rotateIn">
                <i class="fas fa-check-circle fa-3x"></i>
                </p>
                <h3>Order Completed Succesfully </h3>
                <?php endif; ?>
            <!--Grid row-->
                <div class="row wow fadeIn">

                    <!--Grid column-->
                    <div class="col-md-12 ">

                        <!--Card-->
                        <div class="card">

                        <!--Card content-->
                        <div class="card-body">

                            <!-- Table  -->
                            <table class="table table-hover">
                                 <tr>
                                    <th><i class="fas fa-shipping-fast "></i> Shipping  Status</th>
                                      <?php if(session('Order_Cancel_Status')==1): ?>
                                    <td class="disabled" alt="Disaled">  
                                    <?php else: ?> 
                                    <td> 
                                    <?php endif; ?>
                                     <form action="admin-Update-Shipping-Status" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <input type="hidden" value="<?php echo e(session('Order_id')); ?>" name="Order_id">
                                            <input list="Shipping_Status" name="Shipping_Status" id="Shipping_Status" value="<?php echo e(session('Shipping_Status')); ?>">
                                            
                                            <datalist id="Shipping_Status">
         
                                              <option value="Pending">
                                              <option value="Processing">
                                             
                                            </datalist>
                                    <button type="submit">Update</button>
                                    </form>
                                    </td>
                                  </tr>
                                  <tr>
                                    <th><i class="fas fa-truck "></i> Delivery  Status:</th>
                                    <?php if(session('Order_Cancel_Status')==1 || session('Delivery_Status') !='pending' ): ?>
                                    <td class="disabled" alt="Disaled">  
                                    <?php else: ?> 
                                    <td> 
                                    <?php endif; ?>
                                     <form action="admin-Update-Delivery-Status" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <input type="hidden" value="<?php echo e(session('Order_id')); ?>" name="Order_id">
                                           <!-- <input list="Delivery_Status" name="Delivery_Status" id="Delivery_Status" value="<?php echo e(session('Delivery_Status')); ?>">
                                            
                                            <datalist id="Delivery_Status">
         
                                              <option value="Pending">
                                              <option value="Processing">
                                             
                                            </datalist>-->
                                            <?php echo e(session('Delivery_Status')); ?>

                                    <button type="submit">Update</button>
                                    </form>
                                     
                                    </td>
                                  </tr>
                                  <tr> 
                                    <th><i class="fas fa-money-check "></i> Payment Status:</th>
                                    <td>
                                    
                                              <form action="admin-Update-Payment-Status" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <input type="hidden" value="<?php echo e(session('Order_id')); ?>" name="Order_id">
                                            
                                            
                                            <select name="p_status">
                                                <option value="<?php echo e(session('p_status')); ?>" hidden><?php echo e(session('p_status')); ?></option> 
                                              <option value="pending">pending</option>
                                              <option value="completed">completed</option>
                                               <option value="Refunded">Refunded</option>
                                             
                                            </select>
                                    <button type="submit">Update</button>
                                    </form>
                                     </td>
                                  </tr>
                                  <tr>
                                    <th><i class="fas fa-rupee-sign "></i> Payment Mode:</th>
                                    <td> 
                                    
                                           <form action="admin-Update-paymentmode-Status" method="POST">
                                                 <?php echo csrf_field(); ?>
                                                 <input type="hidden" value="<?php echo e(session('Order_id')); ?>" name="Order_id">
                                            
                                            
                                            <select name="paymentmode">
                                                <option value="<?php echo e(session('paymentmode')); ?>" hidden><?php echo e(session('paymentmode')); ?></option> 
                                              <option value="Online">Online</option>
                                              <option value="COD">COD</option>
                                             
                                            </select>
                                    <button type="submit">Update</button>
                                    </form>
                                    
                                    
                                    </td>
                                  </tr>
                            



  
                                    </table>
                                    <!-- Table  -->


                        </div>

                        </div>
                        <!--/.Card-->

                    </div>
                    <!--Grid column-->



                </div>
                <!--Grid row-->
               
                     <p align="left" style="color:red"><br>Note:
                    <ul align="left" style="color:red">
                          <?php if(session('Order_Cancel_Status')==1 ): ?>
                            <li>
                                 It is not possible to update the delivery and shipping status of the cancelled orders...
                            </li>
                            <li>Click <a href="<?php echo e(url('admin-Order-Re-Cancel/'.session('Order_id').'')); ?>" >Here</a> to Re Cancel the this Order</li>
                         <?php else: ?>
                                 <li>
                               It is not possible to update the delivery status for multiple times
                            </li>
                         <?php endif; ?>
                        
                    </ul> 
                 </p>
                
        </div>

            <!--Footer-->
        <div class="modal-footer justify-content-center">
            <a type="button" class="btn btn-outline-success waves-effect" data-dismiss="modal">Close</a>
        </div>
        </div>
        <!--/.Content-->
    </div>
</div>
<!-- Central Modal Medium Success--><?php /**PATH C:\xampp\htdocs\ecommerce_laravel\resources\views/components/admin/orderstatus.blade.php ENDPATH**/ ?>